Nosso trabalho consiste na remodelagem da interface de desenhos de circuitos elétricos do programa LT Spice.

Para implementar algumas das funcionalidades que desejávamos, criamos o protótipo utilizando html. Para testá-lo basta abrir o arquivo "index.html" no navegador de sua preferência.

Observação: toda a barra de opções superior foi implementada apenas ilustrativamente (seus botões não possuem ações). Para mais informações de utilização, favor consultar o relatório.

Em caso de dúvidas durante a avaliação de nosso trabalho, nos contate em qualquer um dos emails:
César Lima: cesar.lima@usp.br
Flavio Santana: flavio.santana@usp.br
